/* CS270 
 *
 * Author: Ryan Blocker
 * Date:   12/1/2021
 */
 
/********** STRUCTURE DEFINITION **********************************************/

// Structure that represents a student
typedef struct
{
  char firstName[80];
  float qualityPoints;
  int numCredits;
} Student;

typedef struct 
{
int numStudents;
Student** students;
} ClassRoster;

/********** FUNCTION PROTOTYPES ***********************************************/

void readStudentAndEnroll(Student **slot);
void displayStudent(Student s);
